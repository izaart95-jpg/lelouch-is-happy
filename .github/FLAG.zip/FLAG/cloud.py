import os
import sys
import platform
import subprocess
import requests
import json
import time
import re
import stat
import tempfile
import threading
from pathlib import Path

# ============================================================
# CONFIGURATION
# ============================================================
TUNNEL_PORT = 8000
TUNNEL_LIFETIME_SECONDS = 3600  # 1 hour
DYNU_API_URL = "https://api.dynu.com/v2/dns/13506963/webRedirect/17628087"
DYNU_API_KEY = "UcX5424UT6VV263Z3ef46UdYc3WT35a7"
DYNU_HEADERS = {
    "accept": "application/json",
    "Content-Type": "application/json",
    "API-Key": DYNU_API_KEY,
}

# Download URLs
CLOUDFLARED_URLS = {
    "windows": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe",
    "linux_amd64": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
    "linux_arm64": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64",
    "linux_arm": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm",
}

# ============================================================
# HELPERS
# ============================================================

def detect_os_arch():
    system = platform.system().lower()
    machine = platform.machine().lower()
    return system, machine


def get_cloudflared_url(system, machine):
    if system == "windows":
        return CLOUDFLARED_URLS["windows"], "cloudflared.exe"
    elif system == "linux":
        if "aarch64" in machine or "arm64" in machine:
            return CLOUDFLARED_URLS["linux_arm64"], "cloudflared"
        elif "arm" in machine:
            return CLOUDFLARED_URLS["linux_arm"], "cloudflared"
        else:
            return CLOUDFLARED_URLS["linux_amd64"], "cloudflared"
    else:
        print(f"[ERROR] Unsupported OS: {system}")
        sys.exit(1)


def get_cloudflared_path(system):
    """
    Returns a stable path inside a temp-like directory so it
    persists across loop iterations without re-downloading every cycle.
    """
    base = Path(tempfile.gettempdir()) / "cloudflared_runner"
    base.mkdir(parents=True, exist_ok=True)
    if system == "windows":
        return base / "cloudflared.exe"
    return base / "cloudflared"


def download_cloudflared(url, dest_path):
    print(f"[INFO] Downloading cloudflared from:\n       {url}")
    print(f"[INFO] Saving to: {dest_path}")
    try:
        with requests.get(url, stream=True, timeout=120) as r:
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0))
            downloaded = 0
            with open(dest_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=1024 * 256):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
            print(f"[INFO] Download complete. ({downloaded} bytes)")
    except Exception as e:
        print(f"[ERROR] Download failed: {e}")
        sys.exit(1)

    # Make executable on Linux
    if platform.system().lower() != "windows":
        st = os.stat(dest_path)
        os.chmod(dest_path, st.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
        print("[INFO] Set executable permission on cloudflared binary.")


def ensure_cloudflared(system, machine):
    """Download only if not already present."""
    dest = get_cloudflared_path(system)
    if dest.exists() and dest.stat().st_size > 1_000_000:
        print(f"[INFO] cloudflared already present at {dest}, skipping download.")
        return dest
    url, _ = get_cloudflared_url(system, machine)
    download_cloudflared(url, dest)
    return dest


# ============================================================
# TUNNEL MANAGEMENT
# ============================================================

def start_tunnel(exe_path):
    """
    Launch cloudflared tunnel and return (process, log_file_path).
    Output is written to a temp file so we can parse it.
    """
    log_file = Path(tempfile.gettempdir()) / "cloudflared_runner" / "tunnel_output.txt"
    log_file.parent.mkdir(parents=True, exist_ok=True)

    # Truncate/create log file
    log_file.write_text("")

    print(f"[INFO] Starting cloudflared tunnel on port {TUNNEL_PORT}...")
    print(f"[INFO] Tunnel log: {log_file}")

    with open(log_file, "w") as lf:
        proc = subprocess.Popen(
            [str(exe_path), "tunnel", "--url", f"http://localhost:{TUNNEL_PORT}"],
            stdout=lf,
            stderr=lf,
            # Detach from current process group so signals don't cascade
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if platform.system().lower() == "windows" else 0,
        )

    print(f"[INFO] cloudflared PID: {proc.pid}")
    return proc, log_file


def extract_tunnel_url(log_path, timeout=60):
    """
    Poll the log file until we find the trycloudflare URL or timeout.
    Returns the URL string or None.
    """
    pattern = re.compile(r'https://[a-z0-9\-]+\.trycloudflare\.com')
    deadline = time.time() + timeout
    print("[INFO] Waiting for tunnel URL (up to 60 s)...")

    while time.time() < deadline:
        try:
            content = log_path.read_text(errors="replace")
            match = pattern.search(content)
            if match:
                url = match.group(0).strip()
                print(f"[INFO] Tunnel URL detected: {url}")
                return url
        except Exception:
            pass
        time.sleep(2)

    # If we reach here, print the log for debugging
    print("[WARN] Timed out waiting for URL. Tunnel log so far:")
    try:
        print(log_path.read_text(errors="replace"))
    except Exception:
        pass
    return None


def kill_tunnel(proc):
    """Terminate the cloudflared process."""
    if proc and proc.poll() is None:
        print(f"[INFO] Terminating cloudflared (PID {proc.pid})...")
        try:
            if platform.system().lower() == "windows":
                proc.terminate()
            else:
                proc.terminate()
            proc.wait(timeout=10)
        except Exception as e:
            print(f"[WARN] Force-killing cloudflared: {e}")
            try:
                proc.kill()
                proc.wait(timeout=5)
            except Exception:
                pass
        print("[INFO] cloudflared terminated.")


# ============================================================
# DYNU UPDATE
# ============================================================

def update_dynu(tunnel_url):
    """Push the tunnel URL to Dynu web-redirect (unchanged logic)."""
    payload = {
        "nodeName": "",
        "redirectType": "UF",
        "state": True,
        "url": tunnel_url,
        "cloak": True,
        "includeQueryString": True,
        "redirect301": False,
        "title": "SRVER",
        "metaKeywords": "SRVER",
        "metaDescription": "SRVER",
    }
    print(f"[INFO] Updating Dynu with URL: {tunnel_url}")
    try:
        resp = requests.post(
            DYNU_API_URL,
            headers=DYNU_HEADERS,
            data=json.dumps(payload),
            timeout=30,
        )
        print(f"[INFO] Dynu response: {resp.status_code} {resp.text}")
    except Exception as e:
        print(f"[ERROR] Dynu update failed: {e}")


# ============================================================
# WATCHDOG — restart if process dies early
# ============================================================

class TunnelSession:
    """Encapsulates one tunnel lifecycle."""

    def __init__(self, exe_path):
        self.exe_path = exe_path
        self.proc = None
        self.log_path = None
        self.url = None
        self._dead_event = threading.Event()

    def start(self):
        self.proc, self.log_path = start_tunnel(self.exe_path)
        self._dead_event.clear()
        self._watcher = threading.Thread(target=self._watch, daemon=True)
        self._watcher.start()

    def _watch(self):
        """Signal if process exits unexpectedly."""
        self.proc.wait()
        self._dead_event.set()

    def is_dead(self):
        return self._dead_event.is_set()

    def get_url(self, timeout=60):
        self.url = extract_tunnel_url(self.log_path, timeout=timeout)
        return self.url

    def stop(self):
        kill_tunnel(self.proc)


# ============================================================
# MAIN LOOP
# ============================================================

def main():
    system, machine = detect_os_arch()
    print(f"[INFO] Detected OS: {system}, Arch: {machine}")

    exe_path = ensure_cloudflared(system, machine)

    cycle = 0
    while True:
        cycle += 1
        print(f"\n{'='*60}")
        print(f"  TUNNEL CYCLE #{cycle}")
        print(f"{'='*60}\n")

        session = TunnelSession(exe_path)
        session.start()

        # Give process a moment to write initial output
        time.sleep(3)

        # Try to get URL; if process died early, retry immediately
        if session.is_dead():
            print("[WARN] cloudflared exited immediately. Retrying in 10 s...")
            session.stop()
            time.sleep(10)
            continue

        tunnel_url = session.get_url(timeout=60)

        if not tunnel_url:
            print("[ERROR] Could not detect tunnel URL. Killing and retrying in 15 s...")
            session.stop()
            time.sleep(15)
            continue

        # Update Dynu immediately after tunnel is up
        update_dynu(tunnel_url)

        # Hold the tunnel for TUNNEL_LIFETIME_SECONDS, checking every 30 s
        print(f"\n[INFO] Tunnel live. Will rotate in {TUNNEL_LIFETIME_SECONDS // 60} minute(s).")
        elapsed = 0
        check_interval = 30
        while elapsed < TUNNEL_LIFETIME_SECONDS:
            time.sleep(check_interval)
            elapsed += check_interval

            if session.is_dead():
                print("[WARN] Tunnel process died unexpectedly. Rotating now.")
                break

            remaining = TUNNEL_LIFETIME_SECONDS - elapsed
            if remaining > 0 and elapsed % 300 == 0:  # log every 5 min
                print(f"[INFO] Tunnel running. {remaining // 60} min until rotation.")

        # Tear down current tunnel
        print("[INFO] Rotating tunnel...")
        session.stop()

        # Brief pause before next cycle
        print("[INFO] Pausing 5 s before starting new tunnel...")
        time.sleep(5)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[INFO] Interrupted by user. Exiting.")
        sys.exit(0)
