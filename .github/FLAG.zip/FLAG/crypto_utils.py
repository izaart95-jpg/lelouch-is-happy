"""
crypto_utils.py
Provides PayloadEncryptor, KeyWrapper, and IntegrityVerifier for
AES-256-GCM file encryption with PBKDF2 key derivation and
timing-safe integrity verification.

Requires: pycryptodome
"""

import os
import base64
import hashlib
import hmac

from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Hash import SHA256, HMAC as CryptoHMAC


class PayloadEncryptor:
    """Encrypts and decrypts files using AES-256-GCM with PBKDF2 key derivation."""

    PBKDF2_ITERATIONS = 100_000
    KEY_LENGTH = 32  # 256 bits
    IV_LENGTH = 12
    SALT_LENGTH = 16

    @staticmethod
    def _derive_key(payload_key: bytes, salt: bytes) -> bytes:
        """Derive the final AES-256 encryption key from payload_key + salt via PBKDF2."""
        derived = PBKDF2(
            password=payload_key,
            salt=salt,
            dkLen=PayloadEncryptor.KEY_LENGTH,
            count=PayloadEncryptor.PBKDF2_ITERATIONS,
            prf=lambda p, s: CryptoHMAC.new(p, s, SHA256).digest(),
        )
        return derived

    def encrypt(self, input_path: str, output_path: str) -> dict:
        """
        Encrypt a file with AES-256-GCM.

        Returns metadata dict:
            payload_key  -- random 32-byte key (bytes)
            iv           -- random 12-byte nonce (bytes)
            salt         -- random 16-byte salt (bytes)
            sha256       -- hex digest of the encrypted output file
        """
        payload_key = os.urandom(self.KEY_LENGTH)
        iv = os.urandom(self.IV_LENGTH)
        salt = os.urandom(self.SALT_LENGTH)

        derived_key = self._derive_key(payload_key, salt)

        with open(input_path, "rb") as f:
            plaintext = f.read()

        cipher = AES.new(derived_key, AES.MODE_GCM, nonce=iv)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext)

        # Encrypted output format: tag (16 bytes) || ciphertext
        encrypted_data = tag + ciphertext

        with open(output_path, "wb") as f:
            f.write(encrypted_data)

        output_hash = hashlib.sha256(encrypted_data).hexdigest()

        return {
            "payload_key": payload_key,
            "iv": iv,
            "salt": salt,
            "sha256": output_hash,
        }

    def decrypt(
        self,
        input_path: str,
        output_path: str,
        payload_key: bytes,
        iv: bytes,
        salt: bytes,
    ) -> bool:
        """
        Decrypt a file previously encrypted with encrypt().

        Returns True on success, False on failure (e.g. bad key / tampered data).
        """
        derived_key = self._derive_key(payload_key, salt)

        with open(input_path, "rb") as f:
            encrypted_data = f.read()

        # Split tag and ciphertext
        tag = encrypted_data[:16]
        ciphertext = encrypted_data[16:]

        try:
            cipher = AES.new(derived_key, AES.MODE_GCM, nonce=iv)
            plaintext = cipher.decrypt_and_verify(ciphertext, tag)
        except (ValueError, KeyError):
            return False

        with open(output_path, "wb") as f:
            f.write(plaintext)

        return True


class KeyWrapper:
    """Wraps and unwraps a payload_key using a user-supplied code (password)."""

    PBKDF2_ITERATIONS = 100_000
    KEY_LENGTH = 32
    WRAPPING_SALT_LENGTH = 16
    WRAPPING_IV_LENGTH = 12

    @staticmethod
    def _derive_wrapping_key(user_code: str, wrapping_salt: bytes) -> bytes:
        """Derive a wrapping key from user_code via PBKDF2."""
        derived = PBKDF2(
            password=user_code.encode("utf-8"),
            salt=wrapping_salt,
            dkLen=KeyWrapper.KEY_LENGTH,
            count=KeyWrapper.PBKDF2_ITERATIONS,
            prf=lambda p, s: CryptoHMAC.new(p, s, SHA256).digest(),
        )
        return derived

    def wrap_key(self, user_code: str, payload_key: bytes) -> dict:
        """
        Wrap (encrypt) the payload_key using a password-derived wrapping key.

        Returns dict with base64-encoded values:
            encrypted_key  -- base64 string (tag + encrypted payload_key)
            wrapping_iv    -- base64 string
            wrapping_salt  -- base64 string
        """
        wrapping_salt = os.urandom(self.WRAPPING_SALT_LENGTH)
        wrapping_iv = os.urandom(self.WRAPPING_IV_LENGTH)

        wrapping_key = self._derive_wrapping_key(user_code, wrapping_salt)

        cipher = AES.new(wrapping_key, AES.MODE_GCM, nonce=wrapping_iv)
        ciphertext, tag = cipher.encrypt_and_digest(payload_key)

        encrypted_key_blob = tag + ciphertext

        return {
            "encrypted_key": base64.b64encode(encrypted_key_blob).decode("utf-8"),
            "wrapping_iv": base64.b64encode(wrapping_iv).decode("utf-8"),
            "wrapping_salt": base64.b64encode(wrapping_salt).decode("utf-8"),
        }

    def unwrap_key(
        self,
        user_code: str,
        encrypted_key_b64: str,
        wrapping_iv_b64: str,
        wrapping_salt_b64: str,
    ) -> bytes:
        """
        Unwrap (decrypt) the payload_key.

        Returns the original payload_key bytes.
        Raises ValueError if the user_code is wrong or data is tampered.
        """
        encrypted_key_blob = base64.b64decode(encrypted_key_b64)
        wrapping_iv = base64.b64decode(wrapping_iv_b64)
        wrapping_salt = base64.b64decode(wrapping_salt_b64)

        wrapping_key = self._derive_wrapping_key(user_code, wrapping_salt)

        tag = encrypted_key_blob[:16]
        ciphertext = encrypted_key_blob[16:]

        cipher = AES.new(wrapping_key, AES.MODE_GCM, nonce=wrapping_iv)
        payload_key = cipher.decrypt_and_verify(ciphertext, tag)
        return payload_key


class IntegrityVerifier:
    """SHA-256 hashing and timing-safe comparison for files and byte data."""

    @staticmethod
    def hash_file(path: str) -> str:
        """Return the SHA-256 hex digest of a file."""
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @staticmethod
    def hash_bytes(data: bytes) -> str:
        """Return the SHA-256 hex digest of arbitrary bytes."""
        return hashlib.sha256(data).hexdigest()

    @staticmethod
    def verify(data_or_path, expected_hash: str) -> bool:
        """
        Timing-safe comparison of expected_hash against the SHA-256 of the input.

        data_or_path can be:
            - bytes  -> hashed directly
            - str    -> treated as a file path and hashed via hash_file
        """
        if isinstance(data_or_path, bytes):
            actual_hash = IntegrityVerifier.hash_bytes(data_or_path)
        elif isinstance(data_or_path, str):
            actual_hash = IntegrityVerifier.hash_file(data_or_path)
        else:
            raise TypeError("data_or_path must be bytes or a file-path string")

        return hmac.compare_digest(actual_hash, expected_hash)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import tempfile

    print("=== crypto_utils self-test ===\n")

    # -- Setup --
    test_payload = b"The quick brown fox jumps over the lazy dog. " * 50
    tmp_dir = tempfile.mkdtemp(prefix="crypto_utils_test_")
    plain_path = os.path.join(tmp_dir, "plain.bin")
    enc_path = os.path.join(tmp_dir, "encrypted.bin")
    dec_path = os.path.join(tmp_dir, "decrypted.bin")

    with open(plain_path, "wb") as f:
        f.write(test_payload)

    # -- 1. Encrypt --
    encryptor = PayloadEncryptor()
    meta = encryptor.encrypt(plain_path, enc_path)
    print(f"[+] Encrypted {len(test_payload)} bytes -> {enc_path}")
    print(f"    payload_key length : {len(meta['payload_key'])} bytes")
    print(f"    iv length          : {len(meta['iv'])} bytes")
    print(f"    salt length        : {len(meta['salt'])} bytes")
    print(f"    sha256 (enc file)  : {meta['sha256']}")

    # -- 2. Verify encrypted file integrity --
    verifier = IntegrityVerifier()
    enc_hash = verifier.hash_file(enc_path)
    assert verifier.verify(enc_path, meta["sha256"]), "Integrity check FAILED on encrypted file"
    print("[+] Encrypted-file integrity verified (timing-safe)")

    # -- 3. Wrap the payload key --
    wrapper = KeyWrapper()
    user_code = "my-secret-code-42"
    wrapped = wrapper.wrap_key(user_code, meta["payload_key"])
    print(f"[+] Wrapped payload_key with user_code")
    print(f"    encrypted_key (b64): {wrapped['encrypted_key'][:40]}...")
    print(f"    wrapping_iv  (b64) : {wrapped['wrapping_iv']}")
    print(f"    wrapping_salt(b64) : {wrapped['wrapping_salt']}")

    # -- 4. Unwrap the payload key --
    recovered_key = wrapper.unwrap_key(
        user_code,
        wrapped["encrypted_key"],
        wrapped["wrapping_iv"],
        wrapped["wrapping_salt"],
    )
    assert recovered_key == meta["payload_key"], "Unwrapped key does not match!"
    print("[+] Unwrapped payload_key matches original")

    # -- 5. Decrypt --
    success = encryptor.decrypt(enc_path, dec_path, recovered_key, meta["iv"], meta["salt"])
    assert success, "Decryption returned False"
    print(f"[+] Decrypted -> {dec_path}")

    # -- 6. Verify decrypted content --
    with open(dec_path, "rb") as f:
        recovered = f.read()
    assert recovered == test_payload, "Decrypted content does not match original!"

    original_hash = verifier.hash_bytes(test_payload)
    assert verifier.verify(recovered, original_hash), "Integrity check FAILED on decrypted data"
    print("[+] Decrypted content matches original (integrity verified)")

    # -- 7. Negative test: wrong user_code must fail unwrap --
    try:
        wrapper.unwrap_key(
            "wrong-code",
            wrapped["encrypted_key"],
            wrapped["wrapping_iv"],
            wrapped["wrapping_salt"],
        )
        print("[-] FAIL: unwrap with wrong code should have raised an error")
    except (ValueError, KeyError):
        print("[+] Correctly rejected wrong user_code during unwrap")

    # -- Cleanup --
    for p in (plain_path, enc_path, dec_path):
        if os.path.exists(p):
            os.remove(p)
    os.rmdir(tmp_dir)

    print("\n=== All self-tests PASSED ===")
