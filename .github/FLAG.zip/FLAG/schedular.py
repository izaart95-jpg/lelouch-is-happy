#!/usr/bin/env python3
"""
scheduler.py — Cross-Platform Unified Cron-Like Scheduler
Runs a configurable build pipeline on Linux and Windows identically.

Usage:
    python scheduler.py [options]

Defaults (all overridable via CLI):
    --interval      60        seconds between cycle starts
    --sleep         10        extra sleep after each cycle
    --payload-url   127.0.0.1:8080
    --output        .
    --input         input.exe
    --target-file   sv2.dat
    --cycles        0         (0 = run forever)
    --python        python    (interpreter to invoke build.py)
    --build-script  build.py
    --dry-run                 print commands but do not execute them
    --skip-obfuscation        pass --skip-obfuscation flag to build.py (default: ON)
    --no-skip-obfuscation     omit the --skip-obfuscation flag
"""

import argparse
import logging
import os
import platform
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

# ──────────────────────────────────────────────
# Logging setup
# ──────────────────────────────────────────────
LOG_FMT = "[%(asctime)s] %(levelname)-8s %(message)s"
DATE_FMT = "%Y-%m-%d %H:%M:%S"

logging.basicConfig(level=logging.INFO, format=LOG_FMT, datefmt=DATE_FMT)
log = logging.getLogger("scheduler")

IS_WINDOWS = platform.system() == "Windows"

# ──────────────────────────────────────────────
# Argument parsing
# ──────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description="Cross-platform periodic build scheduler.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # Timing
    p.add_argument("--interval", type=float, default=60,
                   metavar="SECS",
                   help="seconds between cycle starts (default: 60)")
    p.add_argument("--sleep", type=float, default=10,
                   metavar="SECS",
                   help="extra sleep at end of each cycle (default: 10)")
    p.add_argument("--cycles", type=int, default=0,
                   metavar="N",
                   help="number of cycles to run, 0 = infinite (default: 0)")

    # File targets
    p.add_argument("--target-file", default="sv2.dat",
                   metavar="PATH",
                   help="file to delete before each build (default: sv2.dat)")

    # build.py invocation
    p.add_argument("--build-script", default="build.py",
                   metavar="FILE",
                   help="path to build script (default: build.py)")
    p.add_argument("--python", default=sys.executable,
                   metavar="INTERP",
                   help="Python interpreter for build script (default: current interpreter)")
    p.add_argument("--output", "-o", default=".",
                   metavar="DIR",
                   help="build.py -o argument (default: .)")
    p.add_argument("--payload-url", default="127.0.0.1:8080",
                   metavar="HOST:PORT",
                   help="build.py --payload-url argument (default: 127.0.0.1:8080)")
    p.add_argument("--input", default="input.exe",
                   metavar="FILE",
                   help="positional input file for build.py (default: input.exe)")

    obf = p.add_mutually_exclusive_group()
    obf.add_argument("--skip-obfuscation", dest="skip_obfuscation",
                     action="store_true", default=True,
                     help="pass --skip-obfuscaton to build.py (default: ON)")
    obf.add_argument("--no-skip-obfuscation", dest="skip_obfuscation",
                     action="store_false",
                     help="omit --skip-obfuscaton flag")

    # Behaviour
    p.add_argument("--dry-run", action="store_true",
                   help="print commands without executing them")
    p.add_argument("--verbose", "-v", action="store_true",
                   help="show full command output (default: suppress)")
    p.add_argument("--log-file", metavar="PATH",
                   help="also write log to this file")

    return p.parse_args()

# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def setup_file_logging(path: str):
    fh = logging.FileHandler(path, encoding="utf-8")
    fh.setFormatter(logging.Formatter(LOG_FMT, datefmt=DATE_FMT))
    logging.getLogger().addHandler(fh)
    log.info("Logging to file: %s", path)


def banner(args):
    w = 60
    sep = "─" * w
    log.info(sep)
    log.info("  UNIFIED SCHEDULER  —  %s", platform.system())
    log.info(sep)
    log.info("  Interval      : %ss", args.interval)
    log.info("  Post-sleep    : %ss", args.sleep)
    log.info("  Cycles        : %s", args.cycles if args.cycles else "∞")
    log.info("  Target file   : %s", args.target_file)
    log.info("  Payload URL   : %s", args.payload_url)
    log.info("  Build script  : %s", args.build_script)
    log.info("  Python        : %s", args.python)
    log.info("  Output dir    : %s", args.output)
    log.info("  Input file    : %s", args.input)
    log.info("  Skip obfusc.  : %s", args.skip_obfuscation)
    log.info("  Dry run       : %s", args.dry_run)
    log.info(sep)


# ──────────────────────────────────────────────
# Step 1: Delete target file
# ──────────────────────────────────────────────

def step_delete(target: str, dry_run: bool) -> bool:
    """
    Delete `target` robustly.  Works on both Linux and Windows.
    Equivalent to `rm -rf <target>` / `del /f /q <target>` + rmdir for dirs.
    """
    log.info("STEP 1 — Delete: %s", target)
    p = Path(target)

    if dry_run:
        log.info("  [DRY-RUN] Would delete: %s", p.resolve())
        return True

    if not p.exists():
        log.info("  Target does not exist — skipping delete.")
        return True

    try:
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=False)
            log.info("  Deleted directory: %s", p)
        else:
            p.unlink()
            log.info("  Deleted file: %s", p)
        return True
    except Exception as exc:
        log.error("  Delete failed: %s", exc)
        return False


# ──────────────────────────────────────────────
# Step 2: Run build.py
# ──────────────────────────────────────────────

def build_command(args) -> list:
    """Construct the build.py invocation as a list of strings."""
    cmd = [
        args.python,
        args.build_script,
        "-o", args.output,
        "--payload-url", args.payload_url,
    ]
    if args.skip_obfuscation:
        cmd.append("--skip-obfuscation")   # intentional single-n (matches original)
    cmd.append(args.input)
    return cmd


def step_build(args, dry_run: bool, verbose: bool) -> bool:
    cmd = build_command(args)
    log.info("STEP 2 — Build: %s", " ".join(cmd))

    if dry_run:
        log.info("  [DRY-RUN] Would run: %s", cmd)
        return True

    try:
        result = subprocess.run(
            cmd,
            capture_output=not verbose,
            text=True,
        )
        if verbose and result.stdout:
            for line in result.stdout.splitlines():
                log.info("  [build] %s", line)
        if result.returncode == 0:
            log.info("  Build succeeded (exit 0).")
        else:
            log.warning("  Build exited with code %d.", result.returncode)
            if result.stderr:
                for line in result.stderr.splitlines():
                    log.warning("  [stderr] %s", line)
        return result.returncode == 0
    except FileNotFoundError as exc:
        log.error("  Cannot run build script: %s", exc)
        return False
    except Exception as exc:
        log.error("  Build step error: %s", exc)
        return False


# ──────────────────────────────────────────────
# Step 3: Configurable sleep
# ──────────────────────────────────────────────

def step_sleep(seconds: float, dry_run: bool):
    if seconds <= 0:
        return
    log.info("STEP 3 — Sleep: %.1fs", seconds)
    if not dry_run:
        time.sleep(seconds)


# ──────────────────────────────────────────────
# Main loop
# ──────────────────────────────────────────────

def run_cycle(cycle_num: int, args) -> bool:
    sep = "━" * 60
    log.info(sep)
    log.info("CYCLE %d  —  %s", cycle_num, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    log.info(sep)

    ok1 = step_delete(args.target_file, args.dry_run)
    ok2 = step_build(args, args.dry_run, args.verbose)
    step_sleep(args.sleep, args.dry_run)

    status = "OK" if (ok1 and ok2) else "PARTIAL"
    log.info("Cycle %d complete — %s", cycle_num, status)
    return ok1 and ok2


def main():
    args = parse_args()

    if args.log_file:
        setup_file_logging(args.log_file)

    banner(args)

    cycle = 0
    errors = 0

    try:
        while True:
            cycle += 1
            cycle_start = time.monotonic()

            success = run_cycle(cycle, args)
            if not success:
                errors += 1

            if args.cycles and cycle >= args.cycles:
                log.info("Reached requested cycle limit (%d). Exiting.", args.cycles)
                break

            # Wait for the next interval, accounting for time already spent
            elapsed = time.monotonic() - cycle_start
            wait = max(0.0, args.interval - elapsed)

            if wait > 0:
                log.info("Next cycle in %.1fs  (interval=%.1fs, elapsed=%.1fs)",
                         wait, args.interval, elapsed)
                time.sleep(wait)

    except KeyboardInterrupt:
        log.info("")
        log.info("Interrupted by user after %d cycle(s), %d error(s).", cycle, errors)
        sys.exit(0)
    except Exception as exc:
        log.critical("Unhandled exception: %s", exc, exc_info=True)
        sys.exit(1)

    log.info("Done. Total cycles: %d, errors: %d.", cycle, errors)
    sys.exit(0 if errors == 0 else 1)


if __name__ == "__main__":
    main()
