#!/usr/bin/env python3
"""
SecurePayloadDeliverySystem Backend Server
FastAPI HTTP server + Discord bot for CTF/Hackathon challenge.
"""

import os
import sys
import time
import json
import string
import random
import asyncio
import hashlib
import logging
import threading
from datetime import datetime, timedelta

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse
import uvicorn

# Add current dir to path for crypto_utils import
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from crypto_utils import KeyWrapper, IntegrityVerifier

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(name)s] %(message)s')
logger = logging.getLogger('server')

# ─── Configuration ───────────────────────────────────────────────────────────
SERVER_PORT = int(os.environ.get('SERVER_PORT', '8000'))
DISCORD_BOT_TOKEN = os.environ.get('DISCORD_BOT_TOKEN', '')
ADMIN_CHANNEL_ID = int(os.environ.get('ADMIN_CHANNEL_ID', '0'))
ALLOWED_ROLES = [r.strip() for r in os.environ.get('ALLOWED_ROLES', 'member').split(',') if r.strip()]
PAYLOAD_URL = os.environ.get('PAYLOAD_URL', 'https://www.dropbox.com/s/placeholder/sv2.dat?dl=1')
PAYLOAD_METADATA_PATH = os.environ.get('PAYLOAD_METADATA_PATH',
                                        os.path.join(os.path.dirname(__file__), 'payload_metadata.json'))

FILES_DIR = os.environ.get('FILES_DIR', os.path.join(os.path.dirname(__file__), 'files'))
FILES_WHITELIST = [f.strip() for f in os.environ.get('FILES_WHITELIST', '').split(',') if f.strip()]

SESSION_TTL = 300  # 5 minutes
MAX_ATTEMPTS = 3
MAX_SESSIONS_PER_USER = 3
RATE_LIMIT_PER_MIN = 5
COOLDOWN_SECONDS = 300  # 5 minutes


# ─── Module A3: Session & Key Management ─────────────────────────────────────
class SessionManager:
    def __init__(self):
        self._lock = threading.RLock()
        self._sessions = {}  # code -> session dict
        self._rate_limits = {}  # ip -> [(timestamp, ...)]
        self._cooldowns = {}  # user_id -> last_command_time

    def _generate_code(self):
        chars = string.ascii_letters + string.digits
        while True:
            code = ''.join(random.choices(chars, k=8))
            if code not in self._sessions:
                return code

    def create_session(self, user_id, payload_key, payload_iv, payload_salt,
                       payload_url, expected_sha256):
        """Create session, wrap key, return code."""
        with self._lock:
            # Check max sessions per user
            active = sum(1 for s in self._sessions.values()
                         if s['user_id'] == user_id and s['expires_at'] > time.time())
            if active >= MAX_SESSIONS_PER_USER:
                return None, "Maximum active sessions reached"

            # Check cooldown
            last_cmd = self._cooldowns.get(user_id, 0)
            if time.time() - last_cmd < COOLDOWN_SECONDS:
                remaining = int(COOLDOWN_SECONDS - (time.time() - last_cmd))
                return None, f"Cooldown active, try again in {remaining}s"

            code = self._generate_code()

            # Wrap the payload key with the code
            wrapper = KeyWrapper()
            wrapped = wrapper.wrap_key(code, payload_key)

            now = time.time()
            self._sessions[code] = {
                'code': code,
                'user_id': user_id,
                'created_at': now,
                'expires_at': now + SESSION_TTL,
                'attempts': 0,
                'encrypted_key': wrapped['encrypted_key'],
                'payload_iv': payload_iv,
                'payload_salt': payload_salt,
                'wrapping_iv': wrapped['wrapping_iv'],
                'wrapping_salt': wrapped['wrapping_salt'],
                'payload_url': payload_url,
                'expected_sha256': expected_sha256,
                'client_ips': [],
            }
            self._cooldowns[user_id] = now
            logger.info(f"Session created for user {user_id}, code={code[:3]}***")
            return code, None

    def validate_code(self, code, client_ip=None):
        """Validate code, return session data or None."""
        with self._lock:
            session = self._sessions.get(code)
            if not session:
                return None

            if time.time() > session['expires_at']:
                del self._sessions[code]
                return None

            if session['attempts'] >= MAX_ATTEMPTS:
                return None

            session['attempts'] += 1
            if client_ip and client_ip not in session['client_ips']:
                session['client_ips'].append(client_ip)

            logger.info(f"Code validated: {code[:3]}***, attempt {session['attempts']}")
            return {
                'encrypted_key': session['encrypted_key'],
                'wrapping_iv': session['wrapping_iv'],
                'wrapping_salt': session['wrapping_salt'],
                'payload_url': session['payload_url'],
                'payload_iv': session['payload_iv'],
                'payload_salt': session['payload_salt'],
                'expected_sha256': session['expected_sha256'],
            }

    def cleanup_expired(self):
        with self._lock:
            now = time.time()
            expired = [c for c, s in self._sessions.items() if now > s['expires_at']]
            for c in expired:
                del self._sessions[c]
            if expired:
                logger.info(f"Cleaned up {len(expired)} expired sessions")

    def count_user_sessions(self, user_id):
        with self._lock:
            return sum(1 for s in self._sessions.values()
                       if s['user_id'] == user_id and s['expires_at'] > time.time())

    def check_rate_limit(self, ip):
        with self._lock:
            now = time.time()
            times = self._rate_limits.get(ip, [])
            times = [t for t in times if now - t < 60]
            self._rate_limits[ip] = times
            if len(times) >= RATE_LIMIT_PER_MIN:
                return False
            times.append(now)
            return True


# ─── Global instances ────────────────────────────────────────────────────────
session_mgr = SessionManager()
payload_metadata = {}
_metadata_lock = threading.RLock()
_metadata_mtime = None

def load_payload_metadata():
    global payload_metadata, _metadata_mtime
    if os.path.exists(PAYLOAD_METADATA_PATH):
        try:
            with open(PAYLOAD_METADATA_PATH) as f:
                new_metadata = json.load(f)
            with _metadata_lock:
                payload_metadata = new_metadata
                _metadata_mtime = os.path.getmtime(PAYLOAD_METADATA_PATH)
            logger.info(f"Loaded payload metadata from {PAYLOAD_METADATA_PATH}")
        except Exception as e:
            logger.error(f"Failed to load payload metadata: {e}")
    else:
        logger.warning(f"Payload metadata not found at {PAYLOAD_METADATA_PATH}")

def check_and_reload_metadata():
    """Check if metadata file changed and reload if needed."""
    if not os.path.exists(PAYLOAD_METADATA_PATH):
        return

    try:
        current_mtime = os.path.getmtime(PAYLOAD_METADATA_PATH)
        with _metadata_lock:
            if _metadata_mtime is None or current_mtime > _metadata_mtime:
                logger.info("Detected payload_metadata.json change, reloading...")
                load_payload_metadata()
    except Exception as e:
        logger.error(f"Error checking metadata file: {e}")


# ─── Module A2: FastAPI HTTP Server ──────────────────────────────────────────
app = FastAPI(title="SecurePayloadDeliverySystem", version="1.0")


@app.on_event("startup")
async def startup():
    load_payload_metadata()
    asyncio.create_task(cleanup_loop())


async def cleanup_loop():
    while True:
        await asyncio.sleep(60)
        session_mgr.cleanup_expired()
        check_and_reload_metadata()


@app.post("/api/validate")
async def validate(request: Request):
    client_ip = request.client.host if request.client else "unknown"

    if not session_mgr.check_rate_limit(client_ip):
        return JSONResponse(status_code=429, content={"valid": False, "message": "Rate limit exceeded"})

    try:
        body = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"valid": False, "message": "Invalid JSON"})

    code = body.get("code", "")
    client_id = body.get("client_id", "")

    if not code or len(code) != 8:
        return JSONResponse(status_code=400, content={"valid": False, "message": "Invalid code format"})

    logger.info(f"Validate request from {client_ip}, client_id={client_id}")
    result = session_mgr.validate_code(code, client_ip)

    if result is None:
        return JSONResponse(status_code=401, content={"valid": False, "message": "Invalid or expired code"})

    return {
        "valid": True,
        "encrypted_key": result['encrypted_key'],
        "payload_url": result['payload_url'],
        "payload_iv": result['payload_iv'],
        "payload_salt": result['payload_salt'],
        "wrapping_iv": result['wrapping_iv'],
        "wrapping_salt": result['wrapping_salt'],
        "expected_sha256": result['expected_sha256'],
    }


@app.get("/api/status")
async def status():
    return {"status": "operational", "version": "1.0"}


# ─── Passive File Server ────────────────────────────────────────────────────
@app.get("/files/{filename:path}")
async def serve_file(filename: str):
    # Reject empty filename
    if not filename:
        return JSONResponse(status_code=400, content={"error": "No filename specified"})

    # Path traversal protection: resolve and verify it stays within FILES_DIR
    base = os.path.realpath(FILES_DIR)
    requested = os.path.realpath(os.path.join(base, filename))
    if not requested.startswith(base + os.sep) and requested != base:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    # Whitelist check: if configured, only serve listed filenames
    if FILES_WHITELIST and os.path.basename(filename) not in FILES_WHITELIST:
        return JSONResponse(status_code=403, content={"error": "File not in whitelist"})

    if not os.path.isfile(requested):
        return JSONResponse(status_code=404, content={"error": "File not found"})

    logger.info(f"Serving file: {filename}")
    return FileResponse(requested)


# ─── Module A1: Discord Bot ─────────────────────────────────────────────────
async def run_discord_bot():
    try:
        import discord
        from discord.ext import commands
    except ImportError:
        logger.warning("discord.py not installed, bot disabled")
        return

    intents = discord.Intents.default()
    intents.message_content = True
    bot = commands.Bot(command_prefix='!', intents=intents)

    @bot.event
    async def on_ready():
        logger.info(f"Discord bot connected as {bot.user}")

    @bot.command(name='getapp')
    async def getapp(ctx):
        user_id = str(ctx.author.id)

        # Role check
        if ALLOWED_ROLES and hasattr(ctx.author, 'roles'):
            user_roles = [r.name.lower() for r in ctx.author.roles]
            if not any(r.lower() in user_roles for r in ALLOWED_ROLES):
                await ctx.send("You don't have permission to use this command.", delete_after=10)
                return

        check_and_reload_metadata()
        if not payload_metadata:
            await ctx.send("System not ready. No payload configured.", delete_after=10)
            return

        import base64
        payload_key = base64.b64decode(payload_metadata['payload_key_b64'])
        payload_iv = payload_metadata['payload_iv_b64']
        payload_salt = payload_metadata['payload_salt_b64']
        expected_sha256 = payload_metadata['expected_sha256']
        url = payload_metadata.get('payload_url', PAYLOAD_URL)

        code, error = session_mgr.create_session(
            user_id, payload_key, payload_iv, payload_salt, url, expected_sha256
        )

        if error:
            await ctx.send(f"Error: {error}", delete_after=10)
            return

        try:
            await ctx.author.send(f"Your access code: `{code}`\nExpires in 5 minutes. Single use.")
            await ctx.send("Code sent via DM!", delete_after=5)
        except discord.Forbidden:
            await ctx.send(f"Your access code: ||`{code}`||\nExpires in 5 minutes.", delete_after=30)

        # Admin log
        if ADMIN_CHANNEL_ID:
            channel = bot.get_channel(ADMIN_CHANNEL_ID)
            if channel:
                await channel.send(f"[LOG] Code issued to {ctx.author} ({user_id})")

    await bot.start(DISCORD_BOT_TOKEN)


# ─── Test mode: create session directly ──────────────────────────────────────
@app.post("/api/test/create_session")
async def test_create_session(request: Request):
    """For testing without Discord bot. Creates a session directly."""
    check_and_reload_metadata()
    if not payload_metadata:
        return JSONResponse(status_code=500, content={"error": "No payload metadata loaded"})

    import base64
    body = await request.json()
    user_id = body.get("user_id", "test_user")

    payload_key = base64.b64decode(payload_metadata['payload_key_b64'])
    payload_iv = payload_metadata['payload_iv_b64']
    payload_salt = payload_metadata['payload_salt_b64']
    expected_sha256 = payload_metadata['expected_sha256']
    url = payload_metadata.get('payload_url', PAYLOAD_URL)

    code, error = session_mgr.create_session(
        user_id, payload_key, payload_iv, payload_salt, url, expected_sha256
    )

    if error:
        return JSONResponse(status_code=400, content={"error": error})

    return {"code": code, "expires_in": SESSION_TTL}


# ─── Main ────────────────────────────────────────────────────────────────────
def main():
    load_payload_metadata()

    if DISCORD_BOT_TOKEN:
        logger.info("Starting with Discord bot + HTTP server")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        # Run both
        import threading
        def run_api():
            uvicorn.run(app, host="0.0.0.0", port=SERVER_PORT, log_level="info")

        api_thread = threading.Thread(target=run_api, daemon=True)
        api_thread.start()
        loop.run_until_complete(run_discord_bot())
    else:
        logger.info(f"Starting HTTP server only on port {SERVER_PORT} (no DISCORD_BOT_TOKEN)")
        uvicorn.run(app, host="0.0.0.0", port=SERVER_PORT, log_level="info")


if __name__ == '__main__':
    main()
